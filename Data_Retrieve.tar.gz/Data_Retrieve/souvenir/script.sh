cd souvenir
php batchrename.php >retriever
chmod u+x retriever 
./retriever 
chmod u+x cropper 
./cropper 
chmod u+x eps 
./eps 
chmod u+x souvenir.run 
./souvenir.run 
chmod u+x souvenirnophp.run 
./souvenirnophp.run 

