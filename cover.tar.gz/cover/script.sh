cd imposition/
pdftk frontoutside.pdf empty.pdf frontinside.pdf backinside.pdf empty.pdf backoutside.pdf cat output cover8.pdf
pdflatex imp.tex 
pdflatex imp2.tex
pdftk imp2.pdf cat 1 output final.pdf
acroread final.pdf

